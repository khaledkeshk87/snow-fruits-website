/* SNOW FRUITS CATALOG — imported from Snow_Fruits_Menu.xlsx */
window.SNOW_PRODUCTS = [
  {
    "id": 1,
    "name": "عصير مانجو فاخر",
    "category": "العصائر",
    "size": "250 مل",
    "price": 25,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 2,
    "name": "عصير مانجو فاخر",
    "category": "العصائر",
    "size": "750 مل",
    "price": 65,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 3,
    "name": "عصير مانجو فاخر",
    "category": "العصائر",
    "size": "1 لتر",
    "price": 85,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 4,
    "name": "عصير برتقال فاخر",
    "category": "العصائر",
    "size": "250 مل",
    "price": 20,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 5,
    "name": "عصير برتقال فاخر",
    "category": "العصائر",
    "size": "750 مل",
    "price": 52,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 6,
    "name": "عصير برتقال فاخر",
    "category": "العصائر",
    "size": "1 لتر",
    "price": 68,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 7,
    "name": "عصير برتقال فاخر",
    "category": "العصائر",
    "size": "2 لتر",
    "price": 150,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 8,
    "name": "عصير برتقال فاخر",
    "category": "العصائر",
    "size": "3.6 لتر",
    "price": 220,
    "image": "assets/fruit-cups.jpg",
    "description": "عصير فاخر"
  },
  {
    "id": 9,
    "name": "بطيخ أحمر",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 85,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 10,
    "name": "بطيخ أصفر",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 100,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 11,
    "name": "أفوكادو",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 250,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 12,
    "name": "فراولة",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 85,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 13,
    "name": "رمان",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 85,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 14,
    "name": "جوافة",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 85,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 15,
    "name": "بلح",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 75,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 16,
    "name": "تين شوكي",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 75,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 17,
    "name": "كانتالوب",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 75,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 18,
    "name": "كيوي",
    "category": "الفاكهة المجمدة",
    "size": "1 كيلو",
    "price": 250,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 19,
    "name": "دراجون فروت",
    "category": "الفاكهة المجمدة",
    "size": "500 جرام",
    "price": 150,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 20,
    "name": "كريز أحمر (مستورد)",
    "category": "الفاكهة المجمدة",
    "size": "500 جرام",
    "price": 360,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 21,
    "name": "توت أزرق (مستورد)",
    "category": "الفاكهة المجمدة",
    "size": "500 جرام",
    "price": 360,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  },
  {
    "id": 22,
    "name": "توت أحمر (مستورد)",
    "category": "الفاكهة المجمدة",
    "size": "500 جرام",
    "price": 360,
    "image": "assets/fruit-cups.jpg",
    "description": "فاكهة طازجة مقطعة ومجمدة بنظام IQF"
  }
];
